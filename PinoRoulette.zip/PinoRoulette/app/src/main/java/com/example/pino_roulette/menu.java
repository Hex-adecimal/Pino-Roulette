package com.example.pino_roulette;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class menu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        // Display the back button on left up corner
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Client client = Client.getInstance();

        ArrayList<String> groups = client.getGroups();

        try {
            Thread.sleep(200);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Display groups
        ListView list_chat = findViewById(R.id.list_chat);
        ArrayAdapter<String> arr = new ArrayAdapter<>(this, R.layout.group, groups);
        list_chat.setAdapter(arr);

        // Go to a specific group
        list_chat.setOnItemClickListener((adapterView, view, i, l) -> {
            client.group_name = groups.get(i);
            startActivity(new Intent(getApplicationContext(), group.class));
        });
    }

    // Actually go back
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            startActivity(new Intent(getApplicationContext(), login.class));
            // TODO : delete username password
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}